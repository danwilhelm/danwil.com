//--------------------------------------------------------------------
//Name:		RazorWin.cpp
//Desc:		Wrappers for common Windows tasks	
//--------------------------------------------------------------------

#ifndef RAZORWIN_H_
#define RAZORWIN_H_

BOOL MakeWindow(int WinWidth, int WinHeight);

#endif