
// GENERAL
#define XMSUCCESS			0
#define DIRECTX_UNKNOWN		1
#define COM_UNKNOWN			2
#define XMNOFILE			3
#define XMGENERIC			4
#define XMNOMEM				5

// CLASS CXMedia
#define CXMEDIA_NODDRAW		20
#define CXMEDIA_NODINPUT	21
#define CXMEDIA_NODSOUND	22
#define CXMEDIA_NODMUSIC	23
#define CXMEDIA_KEYIN		24
#define CXMEDIA_MOUSEIN		25
#define CXMEDIA_JOYIN		26
#define CXMEDIA_SETPAL		27
#define CXMEDIA_CHANGEPAL	28
#define CXMEDIA_INVALIDMODE	29
#define CXMEDIA_NOPRIMARY	30

// CLASS CSurface
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_
#define CSURFACE_




