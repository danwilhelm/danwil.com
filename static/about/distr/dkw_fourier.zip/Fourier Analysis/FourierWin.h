//--------------------------------------------------------------------
//Name:		FourierWin.cpp
//Desc:		Wrappers for common Windows tasks
//Author:	
//--------------------------------------------------------------------

#ifndef FOURIERWIN_H_
#define FOURIERWIN_H_

BOOL MakeWindow(int WinWidth, int WinHeight);

#endif