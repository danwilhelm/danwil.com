//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Resources.rc
//
#define DLGOPEN_EDIT                    101
#define DLGOPEN_FILE_LISTBOX            102
#define DLGOPEN_DIR_LISTBOX             103
#define IDI_FOURIER                     103
#define DLGOPEN_PATH                    104
#define DLGOPEN_FOLDOUT                 106
#define DLGOPEN_BIG                     107
#define DLGOPEN_SMALL                   108
#define IDB_SINEWAVE                    109
#define IDC_SINEWAVE                    1000
#define IDS_CAPTION                     1000
#define IDC_SQUAREWAVE                  1001
#define IDC_TRIWAVE                     1002
#define IDC_LOADWAVE                    1003
#define IDC_HARM1                       1005
#define IDC_HARMONICS                   1006
#define IDC_DATASIZE                    1007
#define IDC_HARM2                       1008
#define IDC_HARM3                       1009
#define IDC_HARM4                       1010
#define IDC_HARM5                       1011
#define IDC_HARM6                       1012
#define IDC_SAMPLESPERSEC               1013
#define IDC_SAMPLESTAG                  1014
#define IDC_SIZETAG                     1015
#define IDC_WAVEPROP                    1016
#define IDC_HARMGRAPH                   1017
#define IDC_PLAYWAVE                    1018
#define IDC_STOPWAVE                    1019
#define IDC_POSWAVE                     1021
#define IDC_ZOOMWAVE                    1024
#define IDC_DFT                         1025
#define IDC_FREQ                        1026
#define IDC_DFTCOMPLETE                 1028
#define IDC_GRAPHFREQ                   1029
#define IDC_GRAPHAMP                    1030
#define IDC_MAKEREPORT                  1031
#define IDS_CANTOPENFILE                1100
#define IDS_NOTWAVEFILE                 1110
#define IDS_CORRUPTEDFILE               1120
#define IDS_CANTREADFORMAT              1130
#define IDS_UNSUPPORTEDFORMAT           1140
#define IDS_NOWAVEDATA                  1150
#define IDS_OUTOFMEMORY                 1160
#define IDS_CANTREADDATA                1170
#define IDS_CANTWRITEWAVE               1180
#define IDS_CANTWRITEFORMAT             1190
#define IDS_CANTWRITEDATA               1200
#define IDS_TIMEFMT                     1210
#define IDS_UNTITLED                    1220
#define IDS_CONFIRMCLOSE                1230
#define IDS_OVERWRITE                   1240
#define IDS_BADFREQUENCY                1250
#define IDS_BADRECORDFILE               1260

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1032
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
