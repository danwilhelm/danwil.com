Practical Logic-Based Planning Demo
by Daniel Wilhelm <dan@dkwilhelm.net>

The source code included in this directory accompanies the article "Practical Logic-Based Planning" in the book "AI Game Programming Wisdom 4". It provides a complete logic-based planner which implements many of the extensions mentioned in the article. Note that the output of the included software is the proof of a proposition -- to construct a plan, you must additionally map each rule of the proof onto an action.


I. FEATURES
Many of the extensions from the article are implemented, including:

+ Basic Optimized Planner
+ Iterative Deepening
+ Dynamic Rule Insertion and Removal
+ Value Functions


II. RUNNING THE SOFTWARE
The software can be run in demo mode or it can accept your own rule files. The Windows executable is 'SimplePlanner.exe' in the '/bin' directory. Note that when printing proofs, brackets surrounding the rule number indicates that the rule must be added by another rule before being used.

A. DEMO MODE
To run it in demo mode, execute the program without parameters. The software includes a number of example rule files which illustrate many of the ideas introduced in the article. A menu will appear upon running the program. Upon running each script, the concepts it explores will be listed on-screen.

B. INTERACTIVE MODE
To have the planner accept your own rule files, run it from the command line as follows.

   USAGE: SimplePlanner.exe <script name> <proposition to prove>
   EXAMPLE: SimplePlanner.exe rules_simple.in Barracks


III. SOURCE CODE

The source code for the planner and demo, written in C++, is included in the '/SimplePlanner' directory. A project file is included for Microsoft Visual Studio Express which is compatible with Visual Studio .NET or later. Visual Studio Express can be downloaded for free at http://msdn.microsoft.com/vstudio/express/.

The source code is broken into three files:
  + CPropositionMap.cpp -- Maps proposition strings onto numerical indices and packs propositions into bit vectors.
  + CRuleList.cpp       -- Stores a list of rules, and loads rules from files.
  + CPlanner.cpp        -- Implements the planners.
  + SimplePlanner.cpp   -- Includes demo-specific code which loads a rule file and finds a plan.

The planner included in the source code is heavily modified from the basic algorithm presented in the book to allow for the extensions. However, a function implementing the basic algorithm is included for comparison. The algorithms are implemented in the following functions (in CRuleList.cpp):

  + ConstructProof      -- Initializes 'ConstructProofDepth', and allows for iterative deepening.
  + ConstructProofDepth -- Implements all features listed above. (Internal function -- use 'ContructProof')
  + ConstructProofBasic -- Implements only the basic algorithm (with optimizations) in the article.

If you would like it to run for longer before declaring a failure to find a proof, then change 'MAX_DEPTH' in CRuleList.h.

IV. RULE FILES

The rule files contain a list of facts and production rules. Each rule is specified in the following format, where brackets indicate that the parameter is optional. For clarification, the RuleInitiallyPresent parameter is 0 (not present), then a valid proof cannot use the rule without it being added by another rule first.

# RULE:       1=present       insert rule   remove rule  rule value
# RuleNo RuleInitiallyPresent [I{RuleNo}]   [R{RuleNo}]   [V{amt}]   Consequent [Antecedents ..]

Now for an example:
3 1 I2 I4 V-100 Barracks Worker Gold Lumber

This is rule number three. If the rule is used, then the second and fourth rules are inserted, and the running value is decremented by 100. The rule specifies that Barracks <- Worker ^ Gold ^ Lumber.


If you have any comments, questions, or suggestions about the article or software, please feel free to contact me at the address below. Enjoy!

Daniel Wilhelm
dan@dkwilhelm.net