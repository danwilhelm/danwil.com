/********************************************************
   File: SimplePlanner.cpp
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Includes demo-specific code which loads a rule file 
   and finds a plan.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#include <iostream>
#include <fstream>
#include <conio.h>

#include "CPropositionMap.h"
#include "CRuleList.h"
#include "CProver.h"

// Demo Menu Options
const ULONG numScripts = 6;
const std::string scriptName[] = 
  {"Simple Example", "Cyclic NOT", "Non-cyclic NOT", 
   "Rule Insertion", "Value Functions", "A Limitation"};
const std::string fileName[] = 
  {"rules_simple.in", "rules_neg_cycle.in", "rules_neg_nocycle.in", 
   "rules_insertion.in", "rules_values.in", "rules_limitation.in"};
const std::string propositionToProve[] = 
  {"Barracks", "S", "S", 
   "FireGun", "Castle", "GetPrize"};

void RunDemo(void);
void ProveProposition(std::string fileName, std::string propositionToProve);
void DispProof(std::list<Rule> *proof, CRuleList *rules);
void DispUsage(std::string pathName);


/* Program point of entry. */
int main(int argc, char *argv[])
{
	// User does not want to run the demo?
	if (argc > 1)
	{
		// Entered the correct number of parameters?
		if (argc == 3)
		{
			// Assume that argv[1] is the filename,
			//  argv[2] is the proposition to prove
			ProveProposition(argv[1], argv[2]);
		}
		else
		{
			// Display usage string if user enters any incorrect parameters
			std::cout << std::endl;
			std::cout << "Run this executable without parameters for a demo," << std::endl;
			std::cout << "  or run your own scripts from the commmand line." << std::endl;
			std::cout << std::endl;
			DispUsage(argv[0]);
		}
	}
	else
	{
		// Demo time!
		RunDemo();

		// Usage advertisement
		std::cout << "Run your own scripts from the command line!" << std::endl;
		DispUsage(argv[0]);
	}
	
	return 0;
}


void RunDemo(void)
{
	std::string userInput;
	ULONG inputNum = 0;

	// Repeat the main menu
	do
	{
		std::cout << "---------------------------------------" << std::endl;
		std::cout << "   \"AI Game Programming Wisdom 4\"    " << std::endl;
		std::cout << "  Practical Logic-Based Planning Demo  " << std::endl;
		std::cout << " by Daniel Wilhelm <dan@dkwilhelm.net> " << std::endl;
		std::cout << "---------------------------------------" << std::endl;

		// Display the script names
		for (int i=0; i<numScripts; i++)
		{
			std::cout << ' ' << i+1 << ". " << scriptName[i] << std::endl;
		}

		std::cout << " Q. Exit" << std::endl;
		std::cout << std::endl << "? ";

		std::cin >> userInput;

		switch (userInput[0])
		{
		case 'Q':
		case 'q':
			
			// Exit the program
			break;

		case '1': case '2': case '3':
		case '4': case '5': case '6':
			
			// Select a script to run
			inputNum = (ULONG)(userInput[0] - '1');
			ProveProposition(fileName[inputNum], propositionToProve[inputNum]);

			break;

		default:
			std::cout << "Invalid input. Please select again." << std::endl;
		}

		std::cout << std::endl << std::endl;

	} while (userInput[0] != 'q' && userInput[0] != 'Q');
}


// Prove the proposition 'propositionToProve' given
//  the rule set in the file 'fileName'
void ProveProposition(std::string fileName, std::string propositionToProve)
{
	// Packed bit vector representing the proposition to prove
	ULONG negatedGoal[maxEntries];
	
	std::list<Rule> proof;	// stores the resulting proof
	CPropositionMap map;	// stores symbol->index mapping
	CRuleList rules(&map);	// stores rules from file
	CProver prover;
	CProver::ProofError result = CProver::PROOF_NOTFOUND;

	long value = 0;

	// Check whether input file exists
	std::ifstream inFileStream;
	inFileStream.open(fileName.c_str(), std::ifstream::in);
	inFileStream.close();
	if (inFileStream.fail())
	{
		std::cout << "File '" << fileName << "' does not exist." << std::endl;
		return;
	}

	// Load rules from file
	std::cout << rules.LoadRules(fileName) << std::endl << std::endl;

	// Display the rules
	std::cout << "Rules loaded from file '" << fileName << "':" << std::endl;
	rules.PrintRuleList();

	std::cout << std::endl << "Press any key to prove '";
	std::cout << propositionToProve << "'." << std::endl;
	_getch();

	// Initialize to prove the proposition 'propositionToProve'
	// NOTE: Multiple propositions can be packed into the goal.
	//   Then, it will find a plan to resolve them ANDed together.
	CPropositionMap::ClearPropositions(negatedGoal);
	map.PackPropositions(propositionToProve, negatedGoal);
	proof.clear();

	// Prove the negated goal
	result = prover.ConstructProof(negatedGoal, &proof, &rules, 
		&value, CProver::TYPE_NORMAL, CProver::MAX_DEPTH);

	// Display results
	std::cout << std::endl;
	if (result == CProver::PROOF_NOTFOUND || result == CProver::PROOF_DEPTHREACHED)
	{
		std::cout << "No proof found at depth " << CProver::MAX_DEPTH << "." << std::endl;
	}
	else if (result == CProver::PROOF_NOGOAL)
	{
		std::cout << "Proposition '" << propositionToProve;
		std::cout << "' does not exist in the rules." << std::endl;
	}
	else
	{
		std::cout << std::endl;
		std::cout << "Proof of '" << propositionToProve;
		std::cout << "' (ending value = " << value << "):" << std::endl;
		DispProof(&proof, &rules);
	}
}


/* Display the plan contained in 'proof'. */
void DispProof(std::list<Rule> *proof, CRuleList *rules)
{
	int ruleNum = 0;

	// For each rule ...
	std::list<Rule>::const_iterator ruleIter;
	for (ruleIter = proof->begin(); ruleIter != proof->end(); ruleIter++)
	{
		Rule currRule = *ruleIter;

		// Diplay whether the rule is initially present
		if (currRule.isInitiallyPresent)
		{
			std::cout << " " << currRule.ruleNum << " : ";
		}
		else
		{
			std::cout << "[" << currRule.ruleNum << "]: ";
		}

		rules->PrintRule(&currRule);
		std::cout << std::endl;
	}
}


/* Displays a usage string */
void DispUsage(std::string pathName)
{
	std::string fileName = "";
	std::string::size_type exePos;

	// Find the last '/' or '\' to get the executable name rather
	//  than the entire path
	if ((exePos = pathName.find_last_of('/')) == pathName.npos)
	{
		if ((exePos = pathName.find_last_of('\\')) == pathName.npos)
		{
			fileName = pathName;
		}
	}
	
	if (exePos != pathName.npos)
	{
		fileName = pathName.substr(exePos+1);
	}

	std::cout << "USAGE: " << pathName.substr(exePos+1);
	std::cout << " <script name>" << " <proposition to prove>";
	std::cout << std::endl << std::endl;
	std::cout << "EXAMPLE: " << pathName.substr(exePos+1) << " rules_simple.in Barracks";
	std::cout << std::endl << std::endl;
}
