/********************************************************
   File: CRuleList.h
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Stores a list of rules, loads rules from files, and 
   implements the planner.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#ifndef _CRULELIST
#define _CRULELIST

#include <iostream>
#include <fstream>
#include <sstream>
#include <list>
#include <vector>
#include <string>
#include <map>
#include <cmath>

#include "CPropositionMap.h"


/*
	A rule is an IF/THEN statement:
	  IF antecedent, THEN consequent.

	The antecedent is any number of propositions
	  ANDed together. It is stored as a bit vector,
	  where the ith bit represents the ith proposition
	  of all possible propositions.

	The consequent is a single proposition, stored as 
	  a number i, referring to the ith proposition.
*/ 
struct Rule
{
	ULONG ruleNum;					// ID number
	ULONG consequent;				// Single proposition
	ULONG antecedent[maxEntries];	// Packed proposition bit vector

	std::list<ULONG> insertRules;	// List of rules to insert
	std::list<ULONG> removeRules;	// List of rules to remove
	long valueChange;				// Amount to change the value
	
	bool isInitiallyPresent;		// Whether rule is available initially
};


/* CRuleList
   Rules are IF/THEN statements with at most one consequent.
   
   They can include:
   + Facts: {empty set} -> A ^ B ^ C
   + IF/THEN: A ^ B -> D (IF A and B, THEN D.)

   This class loads rules from files, stores proposition symbol
   to integer conversions, and displays rules.
*/
class CRuleList
{
protected:
	// A hash table providing a list of rules
	//   hashed by their consequent. So,
	// For example:
	// rulesByConsequent[5] evaluates to a list
	//   of all rules which infer the 5th proposition
	std::vector<std::list<Rule> *> rulesByConsequent;

	// Mapping of proposition symbol to integer
	CPropositionMap *propMap;

	/* CRuleList::StringToRule
	Converts a string to a rule. */
	bool StringToRule(Rule *outRule, std::string ruleString);

public:

	/* CRuleList::LoadRules
	Loads a set of rules from a file, and
	creates an appropriate proposition map
	if necessary. */
	std::string LoadRules(std::string fileName);

	/* CRuleList::PrintRuleList
    Prints the list of rules stored in this RuleList to cout. */
	void PrintRuleList(void);

	/* CRuleList::PrintRuleList
    Prints the passed-in rule to cout. */
	void PrintRule(Rule *rule);

	/* CRuleList::AddRule
	Adds a rule to a rule list. */
	void AddRule(Rule rule);

	/* CRuleList::SetPropositionMap
	Accessor for the internal proposition map */
	void SetPropositionMap(CPropositionMap *map);

	
	// Accessor
	std::list<Rule> *GetRules(ULONG propositionIndex)
	{
		return rulesByConsequent[propositionIndex];
	}

	// Constructors/Deconstructor
	CRuleList();
	CRuleList(CPropositionMap *map);
	~CRuleList();
};


/* Identifies facts in proof lists. */
class is_fact : public std::unary_function<Rule, bool> 
{
public:
   bool operator( ) ( Rule &val ) 
   {
	   for (int i=0; i<maxEntries; i++)
	   {
		   // No antecedent indicates a fact
		   if (val.antecedent[i] != 0)
		   {
			   return false;
		   }
	   }

	   return true;
   }
};


#endif
