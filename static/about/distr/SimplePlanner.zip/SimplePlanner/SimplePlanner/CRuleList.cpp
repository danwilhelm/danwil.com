/********************************************************
   File: CRuleList.cpp
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Stores a list of rules, loads rules from files, and 
   implements the planner.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#include <iostream>
#include <ctype.h>
#include "CRuleList.h"

using namespace std;


// Default constructor
CRuleList::CRuleList()
{
}


// Constructor
CRuleList::CRuleList(CPropositionMap *map)
{
	propMap = map;
}


// Destructor
CRuleList::~CRuleList()
{
	for (ULONG i=0; i<rulesByConsequent.size(); i++)
	{
		delete rulesByConsequent[i];
	}
}


/* CRuleList::SetPropositionMap

	Accessor for the internal proposition map */
void CRuleList::SetPropositionMap(CPropositionMap *map)
{
	propMap = map;
}


/* CRuleList::LoadRules

	Loads a set of rules from a file, and
	creates an appropriate proposition map
	if necessary. */
std::string CRuleList::LoadRules(std::string fileName)
{
	std::string topComment;
	std::string ruleString;
	ULONG currProposition = 0;
	ULONG nLines = 0;
	std::list<Rule> ruleList;
	bool inTopComment = true;
	
	std::ifstream inFile(fileName.c_str());

	// Initialize rule list and descriptors
	rulesByConsequent.clear();

	if (inFile.is_open())
	{
		// Each IF/THEN statement is stored on a single line,
		//   so read in lines one-by-one
		inFile.seekg (0, std::ios::beg);
		while (getline(inFile, ruleString))
		{
			// Grab the first commented lines in the file
			//  to return as a file description
			if (ruleString[0] == '#' && inTopComment == true)
			{
				topComment.append(ruleString);
				topComment.append("\n");
			}
			else if (ruleString != "")
			{
				Rule rule;
				
				// Convert each line to a rule
				if (StringToRule(&rule, ruleString))
				{
					AddRule(rule);
				}

				inTopComment = false;
			}
		}
	}
	
	inFile.close();

	return topComment;
}


/* CRuleList::AddRule

	Adds a rule to a rule list. */
void CRuleList::AddRule(Rule rule)
{
	// Has this consequent not been seen before?
	if (rule.consequent >= rulesByConsequent.size())
	{
		// Add rule to a new list for the consequent
		int nConseqToAdd = rule.consequent - rulesByConsequent.size() + 1;

		// Indexed by consequent index, which is numbered starting at zero.
		// So, we must initialize enough spaces for ALL propositions, even
		// if some will not be consequents. Note that almost all should be
		// consequents, however, since otherwise nothing would be proven!
		for (int i=0; i < nConseqToAdd; i++)
		{
			rulesByConsequent.push_back(new std::list<Rule>);
		}
	}

	// Add the new rule to the list for its consequent
	rulesByConsequent[rule.consequent]->push_front(rule);
}


/* CRuleList::StringToRule

	Converts a string to a rule. */
bool CRuleList::StringToRule(Rule *outRule, std::string ruleString)
{
	std::istringstream inSStream;
	std::string currProposition;

	// Has the entire rule been retrieved before a comment?
	bool entireRule = false; 
	bool noConsequent = true;

	// Initialize the antecedent with zero propositions
	CPropositionMap::ClearPropositions(outRule->antecedent);
	outRule->valueChange = 0;

	inSStream.str(ruleString);

	// 1. Mandatory rule number
	if (inSStream >> outRule->ruleNum)
	{
		// 2. Mandatory rule initially present Boolean
		if (inSStream >> outRule->isInitiallyPresent)
		{
			// 3. Mandatory consequent, but before
			//    there may be optional Remove, Insert, Values
			while (noConsequent) 
			{
				if (inSStream >> currProposition)
				{
					if (currProposition[0] == '#')
						return false;

					// Insert, Remove, or Value
					if (currProposition.length() > 1 && 
						(isdigit(currProposition[1]) ||
						 currProposition[1] == '-' || currProposition[1] == '+'))
					{
						int value = atoi(currProposition.substr(1).c_str());
						
						if (currProposition[0] == 'I')
						{
							outRule->insertRules.push_back((ULONG)value);
						}
						else if (currProposition[0] == 'R')
						{
							outRule->removeRules.push_back((ULONG)value);
						}
						else if (currProposition[0] == 'V')
						{
							outRule->valueChange = value;
						}
						else
						{
							return false;
						}
					}
					else
					{
						// If not IRV, then it must be the consequent
						noConsequent = false;
						outRule->consequent = propMap->PropositionToIndex(currProposition);
					}
				}
				else
				{
					return false;
				}
			}

				
			entireRule = true;

			// 4. Optional antecedents (if not a fact)
			while (inSStream >> currProposition)
			{
				if (currProposition[0] == '#')
					break;

				propMap->PackPropositions(propMap->PropositionToIndex(currProposition), outRule->antecedent);
			}
		}
	}

	return entireRule;
}


/* CRuleList::PrintCRuleList

   Prints the list of rules stored in this CRuleList to cout. */
void CRuleList::PrintRuleList(void)
{
	ULONG predIndex = 0;	// predicate index
	std::list<Rule>::const_iterator ruleIter;

	// Loop through rules by consequent
	for (predIndex=0; predIndex<rulesByConsequent.size(); predIndex++)
	{
		// Visit every rule by the given consequent
		for (ruleIter = rulesByConsequent[predIndex]->begin();
			ruleIter != rulesByConsequent[predIndex]->end();
			ruleIter++)
		{
			Rule currRule = *ruleIter;

			
			// Display brackets around rule numbers not
			//   initially present
			if (currRule.isInitiallyPresent == false)
			{
				std::cout << "[" << currRule.ruleNum << "]: ";
			}
			else
			{
				std::cout << " " << currRule.ruleNum << " : ";
			}

			PrintRule(&currRule);

			std::cout << std::endl;
		}
	}

	std::cout << std::endl;
}



/* CRuleList::PrintCRuleList

   Prints the passed-in rule to cout. */
void CRuleList::PrintRule(Rule *rule)
{
	std::list<std::string>::const_iterator propositionIter;
	std::list<std::string> negatedList;

	negatedList.clear();
	propMap->UnpackPropositions(&negatedList, rule->antecedent);

	// Display the consequent
	std::cout << propMap->IndexToProposition(rule->consequent);

	// Display the antecedents
	if (!negatedList.empty())
	{
		std::cout << " <- ";

		propositionIter = negatedList.begin();
		do
		{
			std::cout << *propositionIter;
			propositionIter++;

			if (propositionIter != negatedList.end())
			{
				std::cout << " ^ ";
			}
		} while (propositionIter != negatedList.end());
	}

	// Display the rules to be inserted
	if (!rule->insertRules.empty())
	{
		std::cout << " (Insert: ";

		std::list<ULONG>::const_iterator iter;
		for (iter  = rule->insertRules.begin();
			 iter != rule->insertRules.end(); 
			 iter++)
		{
			ULONG ruleNum = *iter;

			std::cout << ruleNum << " ";
		}

		std::cout << ")";
	}

	// Display the rules to be removed
	if (!rule->removeRules.empty())
	{
		std::cout << " (Remove: ";

		std::list<ULONG>::const_iterator iter;
		for (iter  = rule->removeRules.begin();
			 iter != rule->removeRules.end(); 
			 iter++)
		{
			ULONG ruleNum = *iter;

			std::cout << ruleNum << " ";
		}

		std::cout << ")";
	}

	// Display the value change
	if (rule->valueChange != 0)
	{
		std::cout << " (Value: " << rule->valueChange << ")";
	}
}
