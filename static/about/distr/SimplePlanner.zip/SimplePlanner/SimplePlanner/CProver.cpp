/********************************************************
   File: CProver.cpp
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Contains the planning/prover algorithms.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#include "CRuleList.h"
#include "CProver.h"

/* CPlanner::ConstructProof

	Create a proof of the goal given the rules
	stored in the CRuleList and the type of
	prover given by 'method'. */
CProver::ProofError
CProver::ConstructProof(
	ULONG negatedGoal[], std::list<Rule> *proof, 
	CRuleList *rules, long *value,
	ProofMethod method, ULONG maxdepth)
{
	ProofError proofResult = PROOF_DEPTHREACHED;
	ULONG depth = 0;

	// Is a goal initially present?
	if (CPropositionMap::PackedIsEmpty(negatedGoal) == true)
	{
		return PROOF_NOGOAL;
	}

	// Initialize helper variables
	ClearVars();

	switch(method)
	{
	case TYPE_NORMAL:

		// Runs until a proof is found
		proofResult = ConstructProofDepth(
			negatedGoal, proof, rules, value, maxdepth);
		break;

	case TYPE_SHORTEST:
		
		// Use iterative deepening
		depth = 0;
		while (proofResult == PROOF_DEPTHREACHED && maxdepth < maxdepth)
		{
			depth++;
			proofResult = ConstructProofDepth(
				negatedGoal, proof, rules, value, depth);
		}
		
		break;

	case TYPE_BASIC:

		// Runs until a proof is found
		proofResult = ConstructProofBasic(
			negatedGoal, proof, rules);
		break;

	default:
		break;
	}

	// Because of the dynamic rule insertion/removal feature,
	//  each fact must be verified that it is initially present.
	//  Hence, the facts must be removed from the proof afterward
	//  since only rules correspond to actions.
	RemoveProofFacts(proof);

	return proofResult;
}


/* CPlanner::ResolveGoal

	Given a negated goal and a production rule,
	resolves them as described in the article, removing
	the common proposition. */
_inline void CProver::ResolveGoal(ULONG *resolution, ULONG *negatedGoal, Rule *currRule)
{
	// Get index and offset into the bit vector
	ULONG index  = currRule->consequent / bitsPerULONG;
	ULONG offset = currRule->consequent % bitsPerULONG;

	// Bitwise OR of goal and antecedent
	for (int i=0; i<maxEntries; i++)
	{
		resolution[i] = negatedGoal[i] | currRule->antecedent[i];
	}

	// Remove the complementary propositions
	resolution[index] &= ~(1 << offset);
}


/* CPlanner::InsertRemove

	Set the 'ruleValid' flag if possible when
	 inserting and removing rules. This function
	 returns true if adding 'currRule' to the
	 proof here would be inconsistent. */
bool CProver::InsertRemove(Rule *currRule)
{
	// Insert rules
	std::list<ULONG>::const_iterator insertIter;
	for (insertIter  = currRule->insertRules.begin();
		 insertIter != currRule->insertRules.end();
		 insertIter++)
	{
		ULONG ruleNum = *insertIter;

		if (ruleUsed[ruleNum] == true)
		{
			ruleValid[ruleNum] = true;
		}
	}

	// Remove rules
	for (insertIter  = currRule->removeRules.begin();
		 insertIter != currRule->removeRules.end(); 
		 insertIter++)
	{
		ULONG ruleNum = *insertIter;

		if (ruleUsed[ruleNum] == true &&
			ruleValid[ruleNum] == false)
		{
			return false;
		}
	}

	return true;
}

/* CPlanner::ConstructProofBasic

	Create a proof of the goal given the rules
	stored in the CRuleList. This is the basic
	optimized algorithm found in the article. */
CProver::ProofError 
CProver::ConstructProofBasic(
	ULONG negatedGoal[maxEntries], std::list<Rule> *proof,
	CRuleList *rules)
{
	int i = 0;
	int base = 0;
	ULONG mask = 0;
	
	ULONG resolution[maxEntries];
	Rule rule = {0, negatedGoal[0]};

	// Successful if the goal is empty
	if (CPropositionMap::PackedIsEmpty(negatedGoal))
	{
		return PROOF_SUCCESS;
	}
	else
	{
		// Loop through each negatedGoal Proposition
		for (int entryNum=0; entryNum<maxEntries; entryNum++)
		{
			// Initialize mask to mask the least sig bit
			mask = 1;

			// Loop through each bit
			for (int bitNum=0; bitNum<bitsPerULONG; bitNum++)
			{
				if (negatedGoal[entryNum] & mask)
				{
					ULONG propositionIndex = base + bitNum;

					// Loop through each rule with the necessary consequent
					std::list<Rule>::const_iterator iter;
					for (iter  = rules->GetRules(propositionIndex)->begin();
						 iter != rules->GetRules(propositionIndex)->end(); 
						 iter++)
					{
						Rule currRule = *iter;

						// RESOLUTION
						ResolveGoal(resolution, negatedGoal, &currRule);

						if (ConstructProofBasic(resolution, proof, rules) == PROOF_SUCCESS)
						{
							// Do not add facts to the proof, since only
							//   rules correspond to actions in the plan
							if (currRule.antecedent[0] != 0)
							{
								proof->push_back(currRule);
							}
							
							return PROOF_SUCCESS;
						}
					}
				}
				
				mask <<= 1;
			}
			
			base += bitsPerULONG;
		}
	}

	return PROOF_NOTFOUND;
}


/* CPlanner::ConstructProofDepth

	Create a proof of the goal given the rules
	stored in the CRuleList, stopping when reach
	'maxdepth' depth. This prover contains many
	of the additional features from the article. */
CProver::ProofError 
CProver::ConstructProofDepth(
	ULONG negatedGoal[maxEntries], 
	std::list<Rule> *proof, CRuleList *rules,
	long *value, ULONG maxdepth)
{
	int i = 0;
	int base = 0;
	ULONG mask = 0;
	ProofError result = PROOF_NOTFOUND;

	ULONG resolution[maxEntries];

	// The initial negated goal expressed as a fact
	Rule rule = {0, negatedGoal[0]};

	// Successful if the goal is empty
	if (CPropositionMap::PackedIsEmpty(negatedGoal))
	{
		// Check the proof once generated since insertion/
		//  removal cannot use the initial presence of propositions 
		//  while constructing the proof
		if (ValidateProof(proof, ruleValid) == true)
		{
			return PROOF_SUCCESS;
		}
		else
		{
			return PROOF_NOTFOUND;
		}
	}
	else if (maxdepth == 0)
	{
		// When the maximum depth is reached and a solution 
		//  is not found, exit
		return PROOF_DEPTHREACHED;
	}
	else
	{
		// Loop through each negatedGoal Proposition
		for (int entryNum=0; entryNum<maxEntries; entryNum++)
		{
			// Initialize mask to mask the least sig bit
			mask = 1;

			// Loop through each bit
			for (int bitNum=0; bitNum<bitsPerULONG; bitNum++)
			{
				if (negatedGoal[entryNum] & mask)
				{
					ULONG propositionIndex = base + bitNum;

					// Loop through each rule with the necessary consequent
					std::list<Rule>::const_iterator iter;
					for (iter  = rules->GetRules(propositionIndex)->begin();
						 iter != rules->GetRules(propositionIndex)->end();
						 iter++)
					{
						Rule currRule = *iter;

						ResolveGoal(resolution, negatedGoal, &currRule);

						bool addRule = true;
						std::map<ULONG, bool> tmpAdded = ruleValid;
						
						addRule = InsertRemove(&currRule);

						// Prove it using the new resolution goal!
						//  This maxdepth-1 is purely for aesthetic purposes --
						//  now, it only decreases when a production rule is
						//  used as opposed to a fact so that the "depth"
						//  corresponds to the plan length
						if (addRule == true)
						{
							// Facts must be checked to see if they are initially
							//  valid once a proof is found, and so here we add
							//  rules AND facts to the proof although only rules
							//  constitute a plan. Facts will be removed later.
							
							// Also, note that here we add these then if the proof
							//  was not a success, we remove them. This is so that
							//  we have access to a running total instead of
							//  generating them only once a solution is found.

							proof->push_front(currRule);
							ruleUsed[currRule.ruleNum] = true;
							*value += currRule.valueChange;

							// When a rule is newly added, we do not know whether
							//  it is available or not
							ruleValid[currRule.ruleNum] = false;

							// Note that depth does not correspond to proof length
							//  due to the above.
							result = ConstructProofDepth(
								resolution, proof, rules, value, maxdepth-1);

							if (result == PROOF_SUCCESS)
							{
								return PROOF_SUCCESS;
							}
							else
							{
								*value -= currRule.valueChange;
								proof->pop_front();
								ruleUsed[currRule.ruleNum] = false;
								ruleValid = tmpAdded;

								// Immediately end recursion if depth reached
								if (result == PROOF_DEPTHREACHED)
								{
									return PROOF_DEPTHREACHED;
								}
							}
						}
					}
				}
				
				mask <<= 1;
			}
			
			base += bitsPerULONG;
		}
	}

	return result;
}


/* CPlanner::ValidateProof

	The prover cannot connect whether the rules are initially
	present with its work. Hence, once each possible proof is
	generated (with insertion/removal), the proof must be
	double-checked by this algorithm.*/
bool CProver::ValidateProof(
	std::list<Rule> *proof, std::map<ULONG, bool> ruleAdded)
{
	// For each rule in the proof ...
	std::list<Rule>::const_iterator ruleIter;
	for (ruleIter = proof->begin(); ruleIter != proof->end(); ruleIter++)
	{
		Rule rule = *ruleIter;

		// Rule is valid if it was:
		//  1. Added before it was used (i.e. 'ruleAdded' is true), or if
		//  2. It is initially present and not removed until after it 
		//  is used. (NOTE: If it is removed before it is used, then
		//  the prover would not even add the rule which removes it, so we 
		//  don't have to worry about this!)
		if (ruleAdded[rule.ruleNum] == false && rule.isInitiallyPresent == false)
		{
			return false;
		}
	}

	return true;
}


/* CPlanner::ClearVars

	Clears the 'ruleValid' and 'isUsed' arrays
	 needed for insertion/removal of rules. */
void CProver::ClearVars(void)
{
	// Loop through each rule with the necessary consequent
	std::map<ULONG, bool>::const_iterator iter;
	for (iter  = ruleValid.begin();
		 iter != ruleValid.end(); 
		 iter++)
	{
		std::pair<ULONG, bool> currIsAdded = *iter;

		currIsAdded.second = false;
	}

	// Loop through each rule with the necessary consequent
	for (iter  = ruleUsed.begin();
		 iter != ruleUsed.end(); 
		 iter++)
	{
		std::pair<ULONG, bool> currIsUsed= *iter;

		currIsUsed.second = false;
	}
}


/* CPlanner::ClearRuleFlags

	Clears the flag lists. */
void CProver::ClearRuleFlags(void)
{
	ruleValid.clear();
	ruleUsed.clear();
}


/* CPlanner::RemoveProofFacts

	Removes the facts from a proof list. */
void CProver::RemoveProofFacts(std::list<Rule> *proof)
{
	proof->remove_if(is_fact());
}
