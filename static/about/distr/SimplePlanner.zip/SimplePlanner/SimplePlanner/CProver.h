/********************************************************
   File: CProver.h
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Contains the planning/prover algorithms.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#ifndef _CPROVER
#define _CPROVER

class CProver
{
private:
	// These are mappings from each rule (by ID)
	//  to bit flags -- they are separated from
	//  the main Rule structure due to ease/speed
	//  of access.
	std::map<ULONG, bool> ruleValid;	// Whether rule valid in proof
	std::map<ULONG, bool> ruleUsed;		// Whether rule used yet

	/* CRuleList::ResolveGoal
	Given a negated goal and a production rule,
	resolves them as described in the article, removing
	the common proposition. */
	void ResolveGoal(ULONG *resolution, ULONG *negatedGoal, Rule *currRule);

	/* CRuleList::InsertRemove
	Set the 'ruleValid' flag if possible when
	 inserting and removing rules. This function
	 returns true if adding 'currRule' to the
	 proof here would be inconsistent. */
	bool InsertRemove(Rule *currRule);

	/* CRuleList::ValidateProof
	The prover cannot connect whether the rules are initially
	present with its work. Hence, once each possible proof is
	generated (with insertion/removal), the proof must be
	double-checked by this algorithm.*/
	bool ValidateProof(std::list<Rule> *proof, std::map<ULONG, bool> ruleAdded);
	
	/* CRuleList::RemoveProofFacts
	Removes the facts from a proof list. */
	void RemoveProofFacts(std::list<Rule> *proof);

	/* CRuleList::ClearVars
	Clears the 'ruleValid' and 'isUsed' arrays
	 needed for insertion/removal of rules. */
	void ClearVars(void);

public:

	enum ProofMethod
	{
		TYPE_NORMAL = 0,	// Advanced prover using all features
		TYPE_SHORTEST,		// Iterative deepening
		TYPE_BASIC			// Basic prover without extra features
	};

	enum ProofError
	{
		PROOF_NOTFOUND = 0,	// No proof found
		PROOF_SUCCESS,		// Proof found
		PROOF_DEPTHREACHED,	// Maximum depth has been reached w/o proof
		PROOF_NOGOAL		// No valid goal was passed in to prove
	};

	// Maximum number of iterations for the prover to perform
	//  before stopping.
	const static ULONG MAX_DEPTH = 300;

	/* CRuleList::ConstructProof
	Create a proof of the goal given the rules
	stored in the CRuleList and the type of
	prover given by 'method'. */
	ProofError ConstructProof(
		ULONG negatedGoal[maxEntries], 
		std::list<Rule> *proof, 
		CRuleList *rules,
		long *value, 
		ProofMethod method = TYPE_NORMAL,
		ULONG maxdepth = MAX_DEPTH);
	
	/* CRuleList::ConstructProofBasic
	Create a proof of the goal given the rules
	stored in the CRuleList. This is the basic
	optimized algorithm found in the article. */
	ProofError ConstructProofBasic(
		ULONG negatedGoal[maxEntries], 
		std::list<Rule> *proof,
		CRuleList *rules);

	/* CRuleList::ConstructProofDepth
	Create a proof of the goal given the rules
	stored in the CRuleList, stopping when reach
	'maxdepth' depth. This prover contains many
	of the additional features from the article. */
	ProofError ConstructProofDepth(
		ULONG negatedGoal[maxEntries], 
		std::list<Rule> *proof, 
		CRuleList *rules,
		long *value,
		ULONG maxdepth = MAX_DEPTH);

	/* CPlanner::ClearRuleFlags
	Clears the flag lists. */
	void ClearRuleFlags(void);
};

#endif
