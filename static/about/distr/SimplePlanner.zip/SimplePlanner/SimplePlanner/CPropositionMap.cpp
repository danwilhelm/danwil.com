/********************************************************
   File: CPropositionMap.cpp
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Maps proposition strings onto numerical indices and 
   packs propositions into bit vectors.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#include <iostream>
#include "CPropositionMap.h"

/* CPropositionMap::CPropositionMap

	Constructor. */
CPropositionMap::CPropositionMap()
{
	firstAvailIndex = 0;
}

/* CPropositionMap::IndexToProposition

	Converts a proposition index to a
	proposition symbol. */
std::string CPropositionMap::IndexToProposition(ULONG index)
{
	std::string emptyString = "";

	if (index < firstAvailIndex)
	{
		return indexToProposition[index];
	}
	else
	{
		return emptyString;
	}
}


/* CPropositionMap::PropositionToIndex

	Converts a proposition symbol to an index, and
	creates a new index if one did not exist. */
int CPropositionMap::PropositionToIndex(std::string inStr)
{
	std::map<std::string, int>::const_iterator iter;

	iter = propositionToInt.find(inStr);

	// Does this proposition exist already?
	if (iter != propositionToInt.end())
	{
		return propositionToInt[inStr];
	}
	else
	{
		// Create a new proposition index
		propositionToInt[inStr] = firstAvailIndex;
		indexToProposition[firstAvailIndex] = inStr;
		firstAvailIndex++;
		
		return firstAvailIndex - 1;
	}
}


/* CPropositionMap::UnpackPropositions

	Creates a list of proposition indices from a packed bit vector */
void CPropositionMap::UnpackPropositions(std::list<int> *propositionStr, ULONG packedPropositions[maxEntries])
{
	int base = 0;
	int mask = 1;

	for (int entryNum=0; entryNum<maxEntries; entryNum++)
	{
		mask = 1;

		// Test whether each proposition is in the vector
		for (int bitNum=0; bitNum<bitsPerULONG; bitNum++)
		{
			if (packedPropositions[entryNum] & mask)
			{
				propositionStr->push_back(base + bitNum);
			}

			mask <<= 1;
		}

		base += bitsPerULONG;
	}
}


/* CPropositionMap::UnpackPropositions

	Creates a list of proposition symbols from a packed bit vector */
void CPropositionMap::UnpackPropositions(std::list<std::string> *propositionStr, ULONG packedPropositions[maxEntries])
{
	int base = 0;
	int mask = 1;

	for (int entryNum=0; entryNum<maxEntries; entryNum++)
	{
		mask = 1;

		// Test whether each proposition is in the vector
		for (int bitNum=0; bitNum<bitsPerULONG; bitNum++)
		{
			if (packedPropositions[entryNum] & mask)
			{
				propositionStr->push_back(indexToProposition[base + bitNum]);
			}

			mask <<= 1;
		}

		base += bitsPerULONG;
	}
}


/* CPropositionMap::PackPropositions

   Packs a single proposition index into a packed bit vector. */
void CPropositionMap::PackPropositions(ULONG propositionIndex, ULONG packedPropositions[maxEntries])
{
	ULONG index  = propositionIndex / bitsPerULONG;
	ULONG offset = propositionIndex % bitsPerULONG;

	if (propositionIndex < firstAvailIndex)
	{
		packedPropositions[index] |= 1 << offset;
	}
}


/* CPropositionMap::PackPropositions

   Packs a single proposition symbol into a packed bit vector. */
void CPropositionMap::PackPropositions(std::string propositionStr, ULONG packedPropositions[maxEntries])
{
	if (propositionToInt.find(propositionStr) != propositionToInt.end())
	{
		PackPropositions(propositionToInt[propositionStr], packedPropositions);
	}
}


/* CPropositionMap::PackedIsEmpty

   Determines if no propositions are in a packed bit vector. */
bool CPropositionMap::PackedIsEmpty(ULONG packedPropositions[maxEntries])
{
	for (int i=0; i<maxEntries; i++)
	{
		if (packedPropositions[i] != 0)
		{
			return false;
		}
	}

	return true;
}

/* CPropositionMap::PackedIsEmpty

   Determines if no propositions are in a packed bit vector. */
void CPropositionMap::ClearPropositions(ULONG packedPropositions[maxEntries])
{
	for (int i=0; i<maxEntries; i++)
	{
		packedPropositions[i] = 0;
	}
}
