/********************************************************
   File: CPropositionMap.h
 Author: Daniel Wilhelm <dan@dkwilhelm.net>

 Maps proposition strings onto numerical indices and 
   packs propositions into bit vectors.

 This file is part of the accompanying source code for
   the article "Practical Logic-Based Planning" in
   "AI Game Programming Wisdom 4".
 ********************************************************/

#ifndef _CPROPOSITIONMAP
#define _CPROPOSITIONMAP

#include <map>
#include <string>
#include <list>

typedef unsigned long ULONG;

const ULONG maxEntries = 10;
const ULONG bitsPerByte = 8;
const ULONG bitsPerULONG = sizeof(ULONG) * bitsPerByte;
const ULONG maxPropositions = maxEntries * bitsPerULONG;


class CPropositionMap
{
private:
	// Store a mapping of strings representing 
	//   propositions to integers (and vice versa)
	// For example:
	//    'A' could refer to proposition #5.
	std::map<std::string, int> propositionToInt;
	std::map<int, std::string> indexToProposition;

	// First unused proposition index
	ULONG firstAvailIndex;

public:

	/* CPropositionMap::PropositionToIndex
	Converts a proposition symbol to an index, and
	creates a new index if one did not exist. */
	int PropositionToIndex(std::string inStr);

	/* CPropositionMap::IndexToProposition
	Converts a proposition index to a proposition symbol. */
	std::string IndexToProposition(ULONG index);

	/* CPropositionMap::PackPropositions
    Packs a single proposition symbol into a packed bit vector. */
	void PackPropositions(std::string propositionStr, ULONG packedPropositions[maxEntries]);

	/* CPropositionMap::PackPropositions
    Packs a single proposition index into a packed bit vector. */
	void PackPropositions(ULONG propositionIndex, ULONG packedPropositions[maxEntries]);

	/* CPropositionMap::UnpackPropositions
	Creates a list of proposition indices from a packed bit vector */
	void UnpackPropositions(std::list<int> *PropositionStr, ULONG packedPropositions[maxEntries]);

	/* CPropositionMap::UnpackPropositions
	Creates a list of proposition symbols from a packed bit vector */
	void UnpackPropositions(std::list<std::string> *propositionStr, ULONG packedPropositions[maxEntries]);

	/* CPropositionMap::PackedIsEmpty
    Determines if no propositions are in a packed bit vector. */
	static bool PackedIsEmpty(ULONG *packedPropositions);

	/* CPropositionMap::PackedIsEmpty
    Determines if no propositions are in a packed bit vector. */
	static void ClearPropositions(ULONG packedPropositions[maxEntries]);

	CPropositionMap();
};

#endif
