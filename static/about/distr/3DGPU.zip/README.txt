3DGPU
ECE 495D: ASIC Design Final Project
Purdue University

By James Doty, Kyle McGhee, Allan Patterson, and Daniel Wilhelm.

Description: 
3D Graphics Processing Unit designed for small displays such as cell phones. Wireframe graphics are supported.


Technical Features
�	Architecture allows for 8-bit color 3D line and pixel plotting on a 256x256 LCD display.
�	Depth ordering per pixel implemented through 8-bit w-buffer.
�	Perspective projection applied to all 3D points for realistic depth display.
�	Page flipping architecture allows for no flicker in display rendering.
�	Pass-by-address utilized for opcodes, allowing large data structures (e.g. 64-byte matrices) to be referenced using a single 2-byte value.
�	Three separate SRAM modules allow computer, LCD display, and controller to access data simultaneously without long wait times.
�	Variable frequency for display output.
�	Line algorithm adapted for efficient hardware implementation.
�	Use new 16.16 signed fixed point values for all internal fractional data.
�	Modifiable field of view.


In this distribution, you will find the following directories:
./docs - Technical documentation (including very detailed design document)
./lcd_emulator - C# tool which emulates the LCD display
./opcode_compiler - C program which converts opcodes into a VHDL testbench
./output - Sample image sequence outputs for given test programs
./source - VHDL code for the GPU



Distribution compiled by Daniel Wilhelm [wilhelm@caltech.edu].